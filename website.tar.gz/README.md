# Steal a Magyar YouTuber

## Hoszting információk
- **Eredeti hoszting:** Netlify (eltávolítva)
- **Új hoszting:** GitHub Pages
- **Élő URL:** https://focilaci13.github.io/Steal-a-Magyar-youtuber/

## Telepítés helyi szerveren
1. Klónozás: `git clone https://github.com/focilaci13/Steal-a-Magyar-youtuber.git`
2. Megnyitás: `index.html` böngészőben

## Funkciók
- Google regisztráció/bejelentkezés (Firebase)
- Responsive design
- Magyar YouTuber játék bemutatása