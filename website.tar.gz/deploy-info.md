# GitHub Pages Deployment

## Aktuális URL:
https://focilaci13.github.io/Steal-a-Magyar-youtuber/

## Frissítés módja:
1. Változtatás a kódban
2. `git add .`
3. `git commit -m "frissítés leírása"`
4. `git push`
5. Várj 2 percet

## Státusz ellenőrzése:
- GitHub: https://github.com/focilaci13/Steal-a-Magyar-youtuber/actions
- Élő oldal: https://focilaci13.github.io/Steal-a-Magyar-youtuber/